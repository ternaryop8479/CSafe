#ifndef toDataHome_H
#define toDataHome_H

#include "toFileMemory/toFileMemory.h"
#include <cstring>
#include <string>
#include <functional>
#include <stdexcept>

#define toDataHome_MAGIC "TDH"

struct FileHeader {
    char magic[4];        // 文件标识
    size_t capacity;      // 哈希表容量（条目数）
    size_t count;         // 有效条目数（used且!deleted）
    size_t tombstones;    // 墓碑条目数（deleted）
};

template<size_t KEY_MAX_SIZE, size_t VALUE_MAX_SIZE>
class Entry {
public:
    char key[KEY_MAX_SIZE + 1];   // 键，固定大小
    char value[VALUE_MAX_SIZE + 1]; // 值，固定大小
    bool used;          // 是否已使用
    bool deleted;       // 是否被删除
};

template<size_t KEY_MAX_SIZE, size_t VALUE_MAX_SIZE>
class toDataHome {
private:
    toFileMemory fileMapper;
    FileHeader* header;
    Entry<KEY_MAX_SIZE, VALUE_MAX_SIZE>* entries;
    size_t capacity;

    // 哈希函数（djb2算法）
    size_t hash_function(const char* key) const {
        size_t hash = 5381;
        int c;
        while ((c = *key++)) {
            hash = ((hash << 5) + hash) + c; // hash * 33 + c
        }
        return hash;
    }

public:
    toDataHome() : header(nullptr), entries(nullptr), capacity(0) {}

    size_t open(const std::string& fileName, size_t mapSize) {
        const size_t headerSize = sizeof(FileHeader);
        const size_t entrySize = sizeof(Entry<KEY_MAX_SIZE, VALUE_MAX_SIZE>);
        const size_t requiredFileSize = headerSize + mapSize * entrySize;

        // 映射文件
        void* ptr = fileMapper.open(fileName, requiredFileSize);
        if (!ptr) return 0;

        header = static_cast<FileHeader*>(ptr);
        entries = reinterpret_cast<Entry<KEY_MAX_SIZE, VALUE_MAX_SIZE>*>(header + 1);

        // 检查是否为新建文件
        bool isNewFile = memcmp(header->magic, toDataHome_MAGIC, 4) != 0;
        if (isNewFile) {
            // 初始化新文件
            memcpy(header->magic, toDataHome_MAGIC, 4);
            header->capacity = mapSize;
            header->count = 0;
            header->tombstones = 0;

            // 初始化所有条目
            for (size_t i = 0; i < mapSize; ++i) {
                Entry<KEY_MAX_SIZE, VALUE_MAX_SIZE>& entry = entries[i];
                entry.used = false;
                entry.deleted = false;
                entry.key[0] = '\0';
                entry.value[0] = '\0';
            }
            capacity = mapSize;
            return mapSize;
        } else {
            // 现有文件，检查容量
            size_t currentCapacity = header->capacity;
            if (currentCapacity < mapSize) {
                // 扩容：初始化新增的条目
                for (size_t i = currentCapacity; i < mapSize; ++i) {
                    Entry<KEY_MAX_SIZE, VALUE_MAX_SIZE>& entry = entries[i];
                    entry.used = false;
                    entry.deleted = false;
                    entry.key[0] = '\0';
                    entry.value[0] = '\0';
                }
                header->capacity = mapSize;
                capacity = mapSize;
                return mapSize;
            } else {
                // 容量足够
                capacity = currentCapacity;
                return currentCapacity;
            }
        }
    }

    bool insert(const char* key, const char* value, bool forceInsert = false) {
        if (!header || capacity == 0) return false;

        size_t hash = hash_function(key);
        size_t index = hash % capacity;
        size_t startIndex = index;
        Entry<KEY_MAX_SIZE, VALUE_MAX_SIZE>* existingEntry = nullptr;
        size_t firstTombstone = (size_t)-1;

        // 探测寻找插入位置
        do {
            Entry<KEY_MAX_SIZE, VALUE_MAX_SIZE>& entry = entries[index];
            if (entry.used) {
                if (!entry.deleted) {
                    if (strcmp(entry.key, key) == 0) {
                        existingEntry = &entry;
                        break;
                    }
                } else {
                    // 记录第一个tombstone
                    if (firstTombstone == (size_t)-1) {
                        firstTombstone = index;
                    }
                }
            } else {
                // 找到空槽
                break;
            }
            index = (index + 1) % capacity;
        } while (index != startIndex);

        // 处理已存在的键
        if (existingEntry) {
            if (!forceInsert) return false;
            strncpy(existingEntry->value, value, VALUE_MAX_SIZE);
            existingEntry->value[VALUE_MAX_SIZE] = '\0';
            return true;
        }

        // 寻找插入位置（空槽或tombstone）
        if (index == startIndex && entries[startIndex].used && firstTombstone == (size_t)-1) {
            // 哈希表已满
            return false;
        }

        // 优先使用tombstone
        if (firstTombstone != (size_t)-1) {
            index = firstTombstone;
        }

        Entry<KEY_MAX_SIZE, VALUE_MAX_SIZE>& entry = entries[index];
        if (entry.used && entry.deleted) {
            header->tombstones--;
        }

        // 插入新条目
        strncpy(entry.key, key, KEY_MAX_SIZE);
        entry.key[KEY_MAX_SIZE] = '\0';
        strncpy(entry.value, value, VALUE_MAX_SIZE);
        entry.value[VALUE_MAX_SIZE] = '\0';
        entry.used = true;
        entry.deleted = false;
        header->count++;
        return true;
    }

    std::pair<bool, const char*> find(const char* key) const {
        if (!header || capacity == 0) return {false, nullptr};

        size_t hash = hash_function(key);
        size_t index = hash % capacity;
        size_t startIndex = index;

        do {
            Entry<KEY_MAX_SIZE, VALUE_MAX_SIZE>& entry = entries[index];
            if (entry.used) {
                if (!entry.deleted && strcmp(entry.key, key) == 0) {
                    return {true, entry.value};
                }
            } else {
                // 空槽，停止搜索
                break;
            }
            index = (index + 1) % capacity;
        } while (index != startIndex);

        // 未找到，返回第一个有效值（如果存在）
        if (header->count > 0) {
            for (size_t i = 0; i < capacity; ++i) {
                if (entries[i].used && !entries[i].deleted) {
                    return {false, entries[i].value};
                }
            }
        }
        return {false, nullptr};
    }

    bool remove(const char* key) {
        if (!header || capacity == 0) return false;

        size_t hash = hash_function(key);
        size_t index = hash % capacity;
        size_t startIndex = index;

        do {
            Entry<KEY_MAX_SIZE, VALUE_MAX_SIZE>& entry = entries[index];
            if (entry.used) {
                if (!entry.deleted && strcmp(entry.key, key) == 0) {
                    entry.deleted = true;
                    header->count--;
                    header->tombstones++;
                    return true;
                }
            } else {
                // 未找到
                break;
            }
            index = (index + 1) % capacity;
        } while (index != startIndex);

        return false;
    }

    void close() {
        if (header) {
            fileMapper.save_close();
            header = nullptr;
            entries = nullptr;
            capacity = 0;
        }
    }

    ~toDataHome() {
        close();
    }
};

using toDataHome_default = toDataHome<255, 2047>;

#endif
